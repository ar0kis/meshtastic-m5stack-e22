868 Mhz 6el Yagi antenna by rk3att on Thingiverse: https://www.thingiverse.com/thing:5437281

Summary:
Размеры антенны взяты отсюда: https://dozorfeo.ru/posts/blog/6el-antenna-860-900mhz/Материал элементов - латунная трубка 2мм.В архиве крышка с креплением на трубу 20мм.КСВ ~ 1.1 - 1.2The antenna dimensions are taken from here: https://dozorfeo.ru/posts/blog/6el-antenna-860-900mhz /The material of the elements is a brass tube of 2mm.The archive has a cover with a 20mm pipe attachment.SWR ~ 1.1 - 1.2